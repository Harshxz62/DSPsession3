 
% Function to calculate Circular convolution when three parameters i.e. x1,
% x2 and N are given
function y = myCconv(x1,x2,N)
    if(length(x1)<N)
        temp = zeros(1,N-length(x1));
        x1 = [x1 temp];
    end
    if(length(x2)<N)
        temp = zeros(1,N-length(x2));
        x2 = [x2 temp];
    end
    
    y = zeros(1,N);
    for n=0:N-1
        for k=0:N-1
            j = mod(n-k,N);
            y(n+1)=y(n+1)+(x1(k+1)*x2(j+1));
        end
    end
    
end