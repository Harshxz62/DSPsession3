
% Function to calculate Circular convolution when only two parameters i.e. x1,
% x2 are known.

function y = myCconv1(x1,x2)
    y = myCconv(x1,x2,length(x1)+length(x2)-1);
end
