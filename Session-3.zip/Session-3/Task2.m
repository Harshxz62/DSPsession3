

% Plot 1

x1 = [1,2,3,4,5];
x2 = [3,-1,2,4,5,6,7,8,9,10];
y = myLinconv(x1,x2);
subplot(1,3,1);
stem(y);

% Plot 2

x1 = [3,-1,2,4,5,6,7,8,9,10];
x2 = [1,2,3,4,5];
y = myLinconv(x1,x2);
subplot(1,3,2);
stem(y);

% Plot 3

x1 = [3,-1,2,4,5,6,7,8,9,10];
x2 = [1,1,1,1,1,1,1,1,1,1];
y = myLinconv(x1,x2);
subplot(1,3,3);
stem(y);




