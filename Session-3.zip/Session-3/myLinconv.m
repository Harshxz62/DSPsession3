
% Function to calculate Linear convolution when three parameters i.e. x1,
% x2 given using myCconv function which requires three parameters i.e.
% x1,x2 and N

function y = myLinconv(x1,x2)
    N = length(x1)+length(x2)-1;
    y = myCconv(x1,x2,N);
end