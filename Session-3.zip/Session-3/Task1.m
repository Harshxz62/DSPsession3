
% Plot 1
x1 = [1,2,3,4,5];
x2 = [3,-1,2,4,5,6,7,8,9,10];
y = myCconv1(x1,x2);
subplot(2,3,1);
stem(y);

% Plot 2
x1 = [1,2,3,4,5];
x2 = [3,-1,2,4,5,6,7,8,9,10];
N = 15;
n = [0:14];
y = myCconv(x1,x2,N);
subplot(2,3,2);
stem(n,y);

% Plot 3
x1 = [1,2,3,4,5];
x2 = [3,-1,2,4,5,6,7,8,9,10];
N = 5;
n = [0:4];
y = myCconv(x1,x2,N);
subplot(2,3,3);
stem(n,y);


% Plot 4
x1 = [1,2,3,4,5];
x2 = [3,-1,2,4,5,6,7,8,9,10];
N = 10;
n = [0:9];
y = myCconv(x1,x2,N);
subplot(2,3,4);
stem(n,y);

% Plot 5
x1 = [1,2,3,4,5];
x2 = [3,-1,2,4,5,6,7,8,9,10];
N = 4;
n = [0:3];
y = myCconv(x1,x2,N);
subplot(2,3,5);
stem(n,y);

% Plot 6
x1 = [1,2,3,4,5,6,7,8,9,10];
x2 = [3,-1,2,4,5,6,7,8,9,10];
y = myCconv1(x1,x2);
subplot(2,3,6);
stem(y);